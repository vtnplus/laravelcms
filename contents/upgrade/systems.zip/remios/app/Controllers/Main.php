<?php
namespace Remios\Apps;
class Main extends \Remios\Apps\Controller
{
	public function __construct()
    {
    	//register("style",[resources_url("css/animate.css")]);
    	if(input("setView")){
    		session()->set("content.view_type",input("setView"));
    		return redirect()->back()->send();
    	}

    	if(input("setLanguage")){
    		session()->set("content.language",input("setLanguage"));
    		return redirect()->back()->send();
    	}

    	if(input("setTemplate")){
    		session()->set("content.template",input("setTemplate"));
    		return redirect()->back()->send();
    	}

        if(session()->get("content.language")){
          config()->set("site.language",session()->get("content.language"));
        }
    }

	function getIndex(){
		if(config("site.page_default")){
			return with(new \Modules\Pages\Frontend\Home)->getIndex(config("site.page_default"));
		}
    	return views("home");
    }
}
?>