<?php
namespace Remios;
class Support{
	private $solutions = [];
	public function __construct()
    {
    	$this->solutions = $this->solutions();
    }
	public function solutions(){
		$arv = [];
		$arv["travel"] = [
							"leftmenu" => [
		                    
			                    "name" => "Travel Tour Programs",
			                    "icons" =>  "glyphicon glyphicon-globe",
			                    "contents" => [
			                            "posts/content/manager/travel" => "Chương trình tour",
			                            "catalog/content/manager/travel" => "Loại hình tour",
			                            "catalog/content/manager/detination" => "Điểm đến",
			                            "catalog/content/manager/detinations" => "Điểm đến",
			                                
			                        ],

			                    "sort"  => "p"
		                		]
		                	
                		];

		$arv["hotel"] = [
							"leftmenu" => [
		                    
			                    "name" => "Khách sạn",
			                    "icons" =>  "glyphicon glyphicon-globe",
			                    "contents" => [
			                            "posts/content/manager/hotel" => "Quản lý phòng",
			                            "catalog/content/manager/hotel" => "Phân loại phòng",
			                            
			                                
			                        ],
			                    "sort"  => "p"
		                		]
                		];
		$arv["reast"] = [];

		$arv["products"] = [
							"leftmenu" => [
		                    
			                    "name" => "Bán hàng trực tuyến",
			                    "icons" =>  "glyphicon glyphicon-globe",
			                    "contents" => [
			                            "posts/content/manager/products" => "Danh sách mặt hàng",
			                            "catalog/content/manager/products" => "Phân chuyên mục",
			                            
			                                
			                        ],
			                    "sort"  => "p",
		                		]
                		];


		$arv["product"] = [
							"leftmenu" => [
		                    
			                    "name" => "Giới thiệu sản phẩm",
			                    "icons" =>  "glyphicon glyphicon-globe",
			                    "contents" => [
			                            "posts/content/manager/products" => "Danh sách mặt hàng",
			                            "catalog/content/manager/products" => "Phân chuyên mục",
			                            
			                                
			                        ],
			                    "sort"  => "p"
		                		]
                		];


		$arv["company"] = [];
		return $arv;
	}

	public function register($key=""){

		if(!isset($this->solutions[$key]) || !$key) return false;

		$this->valiedate = $key;
		
		return $this->solutions[$key];
	}


	public function field($key=""){
		$arv = [];
		$arv["products"] = [
			"prices" => "prices",
			"updated_at"	=> "updated_at"
		];
		if(isset($arv[$key])) return $arv[$key];
		return [];
	}
	public function valiedate(){
		return true;
	}
}