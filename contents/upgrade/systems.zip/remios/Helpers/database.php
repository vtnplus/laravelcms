<?php
if(!function_exists("pages")){
    function pages($obj, $append=[]){
        if(method_exists($obj, "render")){
            
            if($append){
                $obj->appends($append);
            }
            echo $obj->render();
        }
    }
}