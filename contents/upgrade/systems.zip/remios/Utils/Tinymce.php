<?php
namespace Remios\Utils;
class Tinymce{
	
	public function attach(){
		
	}
}
